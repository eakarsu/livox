#!/bin/bash

java  -Dcom.sun.management.jmxremote=true -Dcom.sun.management.jmxremote.port=6667 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dorg.slf4j.simpleLogger.logFile=/var/log/livod/livod.log -Dorg.slf4j.simpleLogger.defaultLogLevel=debug -jar bin/felix.jar
